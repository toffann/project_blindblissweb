<?= $this->extend('layout') ?>
<?= $this->section('content') ?>

<div class="card">
  <div class="card-body">
    <h5 class="card-title">Data Product</h5>
    ini adalah halaman product
  </div>
</div>

<?= $this->endSection() ?>